﻿
public class Tyre
{
    private string type;
    private string name;
    private double hardness;
    private double degradation = 100;
    private double Grip { get; set; }

    public string Type
    {
        get { return type; }
        set { type = value; }
    }
    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    public double Hardness
    {
        get { return hardness; }
        set { hardness = value; }
    }
    public double Degradation
    {
        get
        {
            //degradation -= (this.hardness + this.Grip);
            if (Name == "Ultrasoft" && degradation<30)
            {
                 throw new System.Exception();
            }
            if (Name == "Hard" && degradation < 0)
            {
                throw new System.Exception();
            }
            return degradation;
        }
        
        set { degradation = value; }
    }

    

}
//public class Ultrasoft : Tyre
//{
//
//}

//public class Hard : Tyre
//{
//    private double hardness;
//    private double degradation;
//
//    public double Hardness
//    {
//        get { return hardness; }
//        set { hardness = value; }
//    }
//    public double Degradation
//    {
//        get { return degradation -= this.hardness; }
//        set { degradation = value; }
//    }
//}
