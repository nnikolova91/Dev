﻿
    public class Car
    {
        private int hp;
        private double fuelAmount;
        private Tyre tyre;
        

        public int Hp
        {
            get { return hp; }
            set { hp = value; }
        }
        public double FuelAmount
        {
            get { return fuelAmount; }
            set { fuelAmount = value; }
        }
        public Tyre Tyre
        {
            get { return tyre; }
            set { tyre = value; }
        }
    }
