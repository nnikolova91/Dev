﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Cat
{
    public int Test { get; set; }
    
    private int age;
    public int Age
    {
        get
        {
            return age;
        }

        set
        {
            if (value <= 0)
            {
                throw new ArgumentException("godinite trqbva da sa polojitelno chislo");
            }

            age = value;
        }
    }

    private string name;
    public string Name
    {
        get
        {
            return name;
        }
    }

    public Cat(int age, string name)
    {
        this.age = age;
        this.name = name;
    }

    public Cat()
    {
        age = 25;
        name = "gosho";
    }
}


public class Drivers
{
    private string type;
    private string name;
    private double totalTime;
    public double fuelConsumptionPerKm;
    public Car Car { get; set; }
    public double speed;


    public string Type
    {
        get { return type; }
        set { type = value; }
    }
    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    public double TotalTime
    {
        get { return totalTime; }
        set { totalTime = value; }
    }
    public double FuelConsumptionPerKm
    {
        get
        {
            return fuelConsumptionPerKm;
        }
        set { fuelConsumptionPerKm = value; }
    }
    public double Speed
    {
        get
        {
            //speed = (Car.Hp + Car.Tyre.Degradation) / Car.FuelAmount;

            return speed;
        }
        set { speed = value; }
    }

    public Drivers(string type, string name, double hp, double fuelAmount, string tyreType, double tyreHardness)
    {

    }
    public Drivers(string type, string name, double hp, double fuelAmount, string tyreType, double tyreHardness, double grip)
    {

    }
}

