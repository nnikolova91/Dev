﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandPrix
{
    public class RaceTower
    {

        public void SetTrackInfo(int lapsNumber, int trackLength)
        {

        }
        public void RegisterDriver(List<string> commandArgs)
        {
            string type = commandArgs[0];
            string name = commandArgs[1];
            int hp = int.Parse(commandArgs[2]);
            double fuelAmount = double.Parse(commandArgs[3]);
            string typeTyre = commandArgs[4];
            double tyreHardnes = double.Parse(commandArgs[5]);
            double grip = 0;

             
            if (typeTyre == "Ultrasoft")
            {
                grip = double.Parse(commandArgs[6]);

                Tyre tyre = new Ultrasoft("Ultrasoft", tyreHardnes, grip);
                InitializeCarEntDriver(type, name, hp, fuelAmount, tyre);
            }
            else if (typeTyre == "Hard")
            {
                Tyre tyre = new Hard("Ultrasoft", tyreHardnes);
                Car car = new Car(hp, fuelAmount, tyre);
                if (type == "Aggressive")
                {
                    Drivers driver = new AggressivDriver(name, car);
                }
                if (type == "Endurance")
                {
                    Drivers driver = new EnduranceDriver(name, car);    
                }
            }
            


            

        }

        private static void InitializeCarEntDriver(string type, string name, int hp, double fuelAmount, Tyre tyre)
        {
            Car car = new Car(hp, fuelAmount, tyre);
            if (type == "Aggressive")
            {
                Drivers driver = new AggressivDriver(name, car);
            }
            if (type == "Endurance")
            {
                Drivers driver = new EnduranceDriver(name, car);
            }
        }

        public void DriverBoxes()
        {

        }
        public string CompleteLaps()
        {
            return;
        }
        public string GetLeaderboard()
        {
            return;
        }
        public void ChangeWeather()
        {

        }
    }
}
